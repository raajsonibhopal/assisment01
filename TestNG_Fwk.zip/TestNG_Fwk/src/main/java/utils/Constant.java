package utils;

public class Constant {
	public static String ChromeDriverKey="webdriver.chrome.driver";
	public static String ChromeDriverPath="./src/main/resources/drivers/chromedriver.exe";
	
	// for initializing chrome driver
	
	public static String EdgeDriverKey ="webdriver.edge.driver";
	public static String EdgeDriverPath="./src/main/resources/drivers/msedgedriver.exe";
	
	// for initializing edge driver 
	

}
